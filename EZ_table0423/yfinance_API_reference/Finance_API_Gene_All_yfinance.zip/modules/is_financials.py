# =============================================================
# modules/is_financials.py
# 損益表 5Y + TTM + Unusual Items 模組 (雙引擎)
# =============================================================

import time
import random
import logging
import requests
import yfinance as yf
import pandas as pd
import numpy as np
from modules.fmp_client import get_fmp_json

logger = logging.getLogger(__name__)

MAX_RETRIES = 3

def fetch_is_financials(symbol: str, market: str, session: requests.Session) -> pd.DataFrame:
    """雙引擎 IS 抓取"""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            if market == 'US':
                # --- FMP 美股引擎 ---
                data_y = get_fmp_json("/stable/income-statement", symbol, session, {"limit": 5})
                if not data_y:
                    raise ValueError("FMP IS 年度資料為空")
                
                # 年度 DataFrame: 整理成類似 yfinance 格式 (Index=Item, Columns=Years)
                df_y = pd.DataFrame(data_y).set_index("date").T
                # FMP 回傳的 date 是 YYYY-MM-DD，轉成 YYYY
                df_y.columns = pd.to_datetime(df_y.columns).strftime("%Y")
                df_y = df_y.sort_index(axis=1)
                last_5y = df_y.iloc[:, -5:]

                # 季/TTM 資料 (有些 FMP key 會回傳 403 Forbidden 導致程式中斷)
                try:
                    data_q = get_fmp_json("/api/v3/income-statement", symbol, session, {"period": "quarter", "limit": 4})
                except Exception as e:
                    logger.warning(f"[IS] FMP 季報抓取警告 (不影響年度): {e}")
                    data_q = []

                if data_q and len(data_q) >= 4:
                    df_q = pd.DataFrame(data_q).set_index("date").T
                    df_q.columns = pd.to_datetime(df_q.columns)
                    df_q = df_q.sort_index(axis=1)
                    last_4q = df_q.iloc[:, -4:]
                    # 把文字欄位濾掉再算 sum
                    numeric_last_4q = last_4q.apply(pd.to_numeric, errors='coerce')
                    income_ttm = numeric_last_4q.sum(axis=1, skipna=True).to_frame(name="TTM")
                else:
                    income_ttm = pd.DataFrame()
                
                # 拿掉 FMP 中的中繼字串鍵值，避免被當成異常數字
                drop_keys = ["symbol", "reportedCurrency", "cik", "filingDate", "acceptedDate", "period", "link", "finalLink"]
                last_5y = last_5y.drop(index=[k for k in drop_keys if k in last_5y.index], errors='ignore')
                if not income_ttm.empty:
                    income_ttm = income_ttm.drop(index=[k for k in drop_keys if k in income_ttm.index], errors='ignore')
                
                symbol_used = symbol
            else:
                # --- yfinance 台日股引擎 ---
                yf_symbol = symbol
                if market == 'TW':
                    for suffix in [".TW", ".TWO", ".T"]:
                        test_symbol = f"{symbol}{suffix}"
                        if not yf.Ticker(test_symbol).history(period="1d").empty:
                            yf_symbol = test_symbol
                            break

                ticker = yf.Ticker(yf_symbol)
                income_y = ticker.financials.copy()
                if income_y.empty:
                    raise ValueError("無年度資料")

                income_y.columns = pd.to_datetime(income_y.columns)
                income_y = income_y.sort_index(axis=1)
                last_5y = income_y.iloc[:, -5:]
                last_5y.columns = last_5y.columns.strftime("%Y")

                income_q = ticker.quarterly_financials.copy()
                if not income_q.empty and income_q.shape[1] >= 4:
                    income_q.columns = pd.to_datetime(income_q.columns)
                    income_q = income_q.sort_index(axis=1)
                    last_4q = income_q.iloc[:, -4:]
                    income_ttm = last_4q.sum(axis=1).to_frame(name="TTM")
                else:
                    income_ttm = pd.DataFrame()

                symbol_used = yf_symbol

            # ========= 3️⃣ 合併（保證不掉 index） =========
            if not income_ttm.empty:
                combined = pd.concat([last_5y, income_ttm], axis=1)
            else:
                combined = last_5y.copy()

            # ========= 4️⃣ 🔥 絕對保留 Item =========
            combined.index.name = "Item"
            combined_output = combined.reset_index()

            # ========= 5️⃣ 清洗 =========
            for col in combined_output.columns[1:]:
                combined_output[col] = pd.to_numeric(combined_output[col], errors="coerce")

            combined_output = combined_output.replace([np.inf, -np.inf], np.nan)
            combined_output = combined_output.fillna("")

            # ========= 6️⃣ 抓 Unusual =========
            keywords = ["unusual", "special", "restructuring", "non recurring"]
            mask = combined_output["Item"].str.lower().str.contains("|".join(keywords), na=False)
            unusual_output = combined_output[mask]

            # ========= 7️⃣ 加分隔 =========
            if not unusual_output.empty:
                separator = pd.DataFrame([["[ Unusual / Special Items ]"] + [""] * (combined_output.shape[1] - 1)], columns=combined_output.columns)
                final_output = pd.concat([combined_output, separator, unusual_output], ignore_index=True)
            else:
                final_output = combined_output

            logger.info(f"[IS] {symbol_used} 抓取成功（{len(final_output)} 列）")
            return final_output

        except Exception as e:
            logger.warning(f"[IS] {symbol} 第 {attempt}/{MAX_RETRIES} 次失敗: {e}")
            if attempt < MAX_RETRIES:
                time.sleep(random.uniform(3, 7))

    logger.error(f"[IS] {symbol} 超過重試上限，回傳空 DataFrame")
    return pd.DataFrame()
