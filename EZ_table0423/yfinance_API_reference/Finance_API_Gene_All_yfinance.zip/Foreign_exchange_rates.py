import yfinance as yf
import pandas as pd
from datetime import datetime

def fetch_foreign_exchange_rates(currency_code="TWD"):
    symbol = f"USD{currency_code}=X"
    print(f"[{symbol}] 啟動匯率抓取...")
    
    ticker = yf.Ticker(symbol)

    try:
        data = ticker.history(period="5d")
    except:
        print("❌ 無法取得匯率資料")
        return pd.DataFrame()

    if data is None or data.empty:
        print("❌ 無匯率資料")
        return pd.DataFrame()

    latest = data.iloc[-1]
    today_str = datetime.today().strftime("%Y-%m-%d")
    
    exchange_rate = latest["Close"]
    open_price = latest["Open"]
    high_price = latest["High"]
    low_price = latest["Low"]

    result = {
        "Date": today_str,
        "Currency Pair": f"USD/{currency_code}",
        "Exchange Rate (Close)": exchange_rate,
        "Open": open_price,
        "High": high_price,
        "Low": low_price
    }

    df = pd.DataFrame(list(result.items()), columns=["Item", "Value"])
    df = df.fillna("")

    return df