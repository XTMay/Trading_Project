import yfinance as yf
import pandas as pd
from datetime import datetime

def fetch_dividends_action(symbol):
    print(f"[{symbol}] 啟動股息與股票分割抓取...")
    ticker = yf.Ticker(symbol)

    try:
        actions = ticker.actions
    except:
        print("❌ 無法取得 Actions")
        return pd.DataFrame()

    if actions is None or actions.empty:
        print("❌ 無 Actions 資料")
        return pd.DataFrame()

    actions = actions.sort_index(ascending=False)

    output_rows = []

    # 加入標頭資訊
    today_str = datetime.today().strftime("%Y-%m-%d")
    output_rows.append(("Date", today_str))
    output_rows.append(("Ticker", symbol))
    output_rows.append(("", ""))

    # ========= Dividends =========
    dividends = actions[actions["Dividends"] != 0]

    if not dividends.empty:
        output_rows.append(("--- Dividends ---", ""))

        for idx, row in dividends.iterrows():
            date_str = idx.strftime("%Y-%m-%d")
            output_rows.append((date_str, row["Dividends"]))

        output_rows.append(("", ""))

    # ========= Stock Splits =========
    splits = actions[actions["Stock Splits"] != 0]

    if not splits.empty:
        output_rows.append(("--- Stock Splits ---", ""))

        for idx, row in splits.iterrows():
            date_str = idx.strftime("%Y-%m-%d")
            output_rows.append((date_str, row["Stock Splits"]))

    return pd.DataFrame(output_rows, columns=["Item", "Value"])