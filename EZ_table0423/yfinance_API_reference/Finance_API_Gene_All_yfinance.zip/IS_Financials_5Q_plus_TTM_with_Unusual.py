import yfinance as yf
import pandas as pd
import numpy as np

def fetch_is_5q_plus_ttm(ticker_symbol):
    print(f"[{ticker_symbol}] 啟動 IS 5Q+TTM 抓取...")
    ticker = yf.Ticker(ticker_symbol)

    try:
        income_q = ticker.quarterly_financials
    except Exception as e:
        print(f"❌ 無法取得季度資料: {e}")
        return pd.DataFrame()

    if income_q is None or income_q.empty:
        return pd.DataFrame()

    income_q.columns = pd.to_datetime(income_q.columns)
    income_q = income_q.sort_index(axis=1)

    if income_q.shape[1] >= 5:
        last_5q = income_q.iloc[:, -5:]
    else:
        last_5q = income_q

    last_5q.columns = last_5q.columns.strftime("%Y-%m")

    if income_q.shape[1] >= 4:
        last_4q = income_q.iloc[:, -4:]
        income_ttm = last_4q.sum(axis=1).to_frame(name="TTM")
    else:
        print("⚠ 季度資料不足4季，無法計算TTM")
        income_ttm = pd.DataFrame(index=income_q.index, columns=["TTM"])

    combined = last_5q.merge(
        income_ttm,
        left_index=True,
        right_index=True,
        how="left"
    )

    def sanitize_excel(df):
        df = df.copy()
        for col in df.columns:
            if col != "Item":
                df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.replace([np.inf, -np.inf], np.nan)
        df = df.fillna("")
        return df

    keywords = ["unusual", "special", "restructuring", "non recurring"]
    unusual_rows = combined.loc[
        combined.index.astype(str).str.lower().str.contains("|".join(keywords))
    ]

    combined.index.name = "Item"
    combined_output = combined.reset_index()
    combined_output = sanitize_excel(combined_output)

    if not unusual_rows.empty:
        unusual_rows.index.name = "Item"
        unusual_output = unusual_rows.reset_index()
        unusual_output = sanitize_excel(unusual_output)

        separator = pd.DataFrame(
            [["[ Unusual / Special Items ]"] +
             [""] * (combined_output.shape[1] - 1)],
            columns=combined_output.columns
        )

        final_output = pd.concat(
            [combined_output, separator, unusual_output],
            ignore_index=True
        )
    else:
        final_output = combined_output

    return final_output