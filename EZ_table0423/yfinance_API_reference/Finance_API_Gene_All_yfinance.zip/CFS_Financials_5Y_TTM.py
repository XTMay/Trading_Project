import yfinance as yf
import pandas as pd
import numpy as np

def fetch_cfs_5y_ttm(ticker_symbol):
    print(f"[{ticker_symbol}] 啟動 CFS 5Y+TTM 抓取...")
    ticker = yf.Ticker(ticker_symbol)

    try:
        cf_y = ticker.cashflow
    except Exception as e:
        print(f"❌ 無法取得年度 Cash Flow: {e}")
        return pd.DataFrame()

    if cf_y is None or cf_y.empty:
        print("❌ 無法取得年度 Cash Flow")
        return pd.DataFrame()

    cf_y.columns = pd.to_datetime(cf_y.columns)
    cf_y = cf_y.sort_index(axis=1)

    try:
        cf_q = ticker.quarterly_cashflow
    except:
        cf_q = pd.DataFrame()

    if not cf_q.empty:
        cf_q.columns = pd.to_datetime(cf_q.columns)
        cf_q = cf_q.sort_index(axis=1)

    def check_year_integrity(df):
        dates = df.columns.sort_values()
        if len(dates) < 5:
            print("⚠ 年度資料不足5年")
            return "LESS_THAN_5"
        diffs = np.diff(dates).astype("timedelta64[D]").astype(int)
        for d in diffs[-5:]:
            if not (330 <= d <= 400):
                print("⚠ 偵測到年度不連續")
                return "BROKEN"
        return "VALID"

    status = check_year_integrity(cf_y)

    if status == "VALID":
        print("✅ 年度完整 → 輸出最近5年")
        last_y = cf_y.iloc[:, -5:]
    elif status == "LESS_THAN_5":
        print("🔄 不足5年 → 輸出所有年度")
        last_y = cf_y
    else:
        print("🔄 年度不連續 → 輸出最近單年")
        last_y = cf_y.iloc[:, -1:]

    last_y.columns = last_y.columns.strftime("%Y")

    if not cf_q.empty:
        if cf_q.shape[1] >= 4:
            print("✅ 使用最近4季加總計算 TTM")
            last_4q = cf_q.iloc[:, -4:]
            cf_ttm = last_4q.sum(axis=1).to_frame(name="TTM")
        else:
            print("⚠ 季度不足4季 → 使用最近季度")
            cf_ttm = cf_q.iloc[:, -1:].copy()
            cf_ttm.columns = ["TTM"]
    else:
        print("⚠ 無法取得季度資料 → 使用最新年度作為 TTM")
        cf_ttm = cf_y.iloc[:, -1:].copy()
        cf_ttm.columns = ["TTM"]

    combined = last_y.merge(
        cf_ttm,
        left_index=True,
        right_index=True,
        how="left"
    )

    def sanitize_excel(df):
        df = df.copy()
        for col in df.columns:
            if col != "Item":
                df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.replace([np.inf, -np.inf], np.nan)
        df = df.fillna("")
        return df

    combined.index.name = "Item"
    combined_output = combined.reset_index()
    combined_output = sanitize_excel(combined_output)

    return combined_output