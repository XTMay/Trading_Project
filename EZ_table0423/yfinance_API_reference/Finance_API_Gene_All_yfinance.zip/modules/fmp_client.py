# =============================================================
# modules/fmp_client.py
# FMP API (美股引擎) 封裝
# =============================================================
import requests
import re

FMP_API_KEY = "hwCzbwI2zXSu7DKQ8iiF0vtKTeSCQ19y"
FMP_BASE    = "https://financialmodelingprep.com"

_RE_US  = re.compile(r'^[A-Za-z]{1,5}$')
_RE_TW  = re.compile(r'^\d{4}$')

def classify_symbol(raw_val):
    """
    分類股票代碼：回傳 (symbol, market)
    market: 'US' | 'TW' | 'skip'
    """
    raw_str = str(raw_val).strip()
    num_match = re.match(r'^[^\d]*(\d+)', raw_str)
    alpha_match = re.match(r'^([A-Za-z]{1,5})$', raw_str)

    if alpha_match:
        return alpha_match.group(1).upper(), 'US'
    if num_match:
        digits = num_match.group(1)
        if _RE_TW.match(digits):
            return digits, 'TW'
    return None, 'skip'

def get_fmp_json(endpoint: str, symbol: str, session: requests.Session, params: dict = None):
    """呼叫 FMP API 並回傳 JSON"""
    if params is None:
        params = {}
    params['apikey'] = FMP_API_KEY
    params['symbol'] = symbol
    query_str = "&".join([f"{k}={v}" for k, v in params.items()])
    url = f"{FMP_BASE}{endpoint}?{query_str}"
    
    r = session.get(url, timeout=15)
    r.raise_for_status()
    data = r.json()
    if not isinstance(data, list):
        return []
    return data
