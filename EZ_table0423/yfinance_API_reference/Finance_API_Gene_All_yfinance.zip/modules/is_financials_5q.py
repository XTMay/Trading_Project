# =============================================================
# modules/is_financials_5q.py
# 損益表 5Q + TTM + Unusual Items 模組 (yfinance 專用)
# =============================================================

import time
import random
import logging
import requests
import yfinance as yf
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

MAX_RETRIES = 3

def sanitize_excel(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if col != "Item":
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.fillna("")
    return df

def fetch_is_financials_5q(symbol: str, market: str, session: requests.Session) -> pd.DataFrame:
    """單一 yfinance 引擎 IS 5季抓取"""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            # --- 統一使用 yfinance 引擎 ---
            yf_symbol = symbol
            if market == 'TW':
                for suffix in [".TW", ".TWO", ".T"]:
                    test_symbol = f"{symbol}{suffix}"
                    if not yf.Ticker(test_symbol).history(period="1d").empty:
                        yf_symbol = test_symbol
                        break

            ticker = yf.Ticker(yf_symbol)
            
            # ========= 1️⃣ 抓季度資料 =========
            income_q = ticker.quarterly_financials
            if income_q.empty:
                raise ValueError("無法取得季度資料")

            income_q.columns = pd.to_datetime(income_q.columns)
            income_q = income_q.sort_index(axis=1)

            # ========= 2️⃣ 最近5季 =========
            if income_q.shape[1] >= 5:
                last_5q = income_q.iloc[:, -5:]
            else:
                last_5q = income_q

            last_5q.columns = last_5q.columns.strftime("%Y-%m")

            # ========= 3️⃣ 計算 TTM =========
            if income_q.shape[1] >= 4:
                last_4q = income_q.iloc[:, -4:]
                income_ttm = last_4q.sum(axis=1).to_frame(name="TTM")
            else:
                raise ValueError("季度資料不足4季，無法計算TTM")

            # ========= 4️⃣ 合併 =========
            combined = last_5q.merge(
                income_ttm,
                left_index=True,
                right_index=True,
                how="left"
            )

            # ========= 5️⃣ 抓 Unusual =========
            keywords = ["unusual", "special", "restructuring", "non recurring"]
            unusual_rows = combined.loc[
                combined.index.str.lower().str.contains("|".join(keywords))
            ]

            # ========= 6️⃣ 重設 index =========
            combined.index.name = "Item"
            combined_output = combined.reset_index()
            combined_output = sanitize_excel(combined_output)

            if not unusual_rows.empty:
                unusual_rows.index.name = "Item"
                unusual_output = unusual_rows.reset_index()
                unusual_output = sanitize_excel(unusual_output)

                separator = pd.DataFrame(
                    [["[ Unusual / Special Items ]"] +
                     [""] * (combined_output.shape[1] - 1)],
                    columns=combined_output.columns
                )

                final_output = pd.concat(
                    [combined_output, separator, unusual_output],
                    ignore_index=True
                )
            else:
                final_output = combined_output

            logger.info(f"[IS 5Q] {yf_symbol} 抓取成功（{len(final_output)} 列）")
            return final_output

        except Exception as e:
            logger.warning(f"[IS 5Q] {symbol} 第 {attempt}/{MAX_RETRIES} 次失敗: {e}")
            if attempt < MAX_RETRIES:
                time.sleep(random.uniform(3, 7))

    logger.error(f"[IS 5Q] {symbol} 超過重試上限，回傳空 DataFrame")
    return pd.DataFrame()
