# =============================================================
# modules/bs_financials.py
# 資產負債表（Balance Sheet）5Y + TTM 模組 (雙引擎)
# =============================================================

import time
import random
import logging
import requests
import yfinance as yf
import pandas as pd
import numpy as np
from modules.fmp_client import get_fmp_json

logger = logging.getLogger(__name__)

MAX_RETRIES = 3

def check_year_integrity(df) -> str:
    dates = df.columns.sort_values()
    if len(dates) < 5:
        logger.warning("⚠ 年度資料不足5年")
        return "LESS_THAN_5"
    diffs = np.diff(dates).astype("timedelta64[D]").astype(int)
    for d in diffs[-5:]:
        # 如果是 FMP 年資料，天數落差可能在 360~370 左右
        if not (330 <= d <= 400):
            logger.warning("⚠ 偵測到年度不連續")
            return "BROKEN"
    return "VALID"

def sanitize_excel(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if col != "Item":
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.fillna("")
    return df

def fetch_bs_financials(symbol: str, market: str, session: requests.Session) -> pd.DataFrame:
    """雙引擎 BS 抓取"""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            if market == 'US':
                # --- FMP 美股引擎 ---
                data_y = get_fmp_json("/stable/balance-sheet-statement", symbol, session, {"limit": 5})
                if not data_y:
                    raise ValueError("FMP BS 年度資料為空")
                
                df_y = pd.DataFrame(data_y).set_index("date").T
                df_y.columns = pd.to_datetime(df_y.columns)
                df_y = df_y.sort_index(axis=1)

                drop_keys = ["symbol", "reportedCurrency", "cik", "filingDate", "acceptedDate", "period", "link", "finalLink"]
                df_y = df_y.drop(index=[k for k in drop_keys if k in df_y.index], errors='ignore')

                bs_y = df_y
                symbol_used = symbol
            else:
                # --- yfinance 台日股引擎 ---
                yf_symbol = symbol
                if market == 'TW':
                    for suffix in [".TW", ".TWO", ".T"]:
                        test_symbol = f"{symbol}{suffix}"
                        if not yf.Ticker(test_symbol).history(period="1d").empty:
                            yf_symbol = test_symbol
                            break

                ticker = yf.Ticker(yf_symbol)
                bs_y = ticker.balance_sheet
                if bs_y.empty:
                    raise ValueError("❌ 無法取得年度 Balance Sheet")

                bs_y.columns = pd.to_datetime(bs_y.columns)
                bs_y = bs_y.sort_index(axis=1)
                symbol_used = yf_symbol

            # ========= 2️⃣ 年度完整性判斷 =========
            status = check_year_integrity(bs_y)

            if status == "VALID":
                logger.info(f"[BS] {symbol_used} 年度完整 → 輸出最近5年 + TTM")
                last_y = bs_y.iloc[:, -5:]
            elif status == "LESS_THAN_5":
                logger.info(f"[BS] {symbol_used} 不足5年 → 輸出所有年度 + TTM")
                last_y = bs_y
            else:  # BROKEN
                logger.info(f"[BS] {symbol_used} 年度不連續 → 輸出最近單年 + TTM")
                last_y = bs_y.iloc[:, -1:]

            last_y.columns = last_y.columns.strftime("%Y")

            # ========= 3️⃣ TTM = 最新年度 copy =========
            bs_ttm = bs_y.iloc[:, -1:].copy()
            bs_ttm.columns = ["TTM"]

            # ========= 4️⃣ 合併 =========
            combined = last_y.merge(
                bs_ttm,
                left_index=True,
                right_index=True,
                how="left"
            )

            # ========= 5️⃣ 清洗 =========
            combined.index.name = "Item"
            combined_output = combined.reset_index()
            combined_output = sanitize_excel(combined_output)

            logger.info(f"[BS] {symbol_used} 抓取成功（{len(combined_output)} 列）")
            return combined_output

        except Exception as e:
            logger.warning(f"[BS] {symbol} 第 {attempt}/{MAX_RETRIES} 次失敗: {e}")
            if attempt < MAX_RETRIES:
                time.sleep(random.uniform(3, 7))

    logger.error(f"[BS] {symbol} 超過重試上限，回傳空 DataFrame")
    return pd.DataFrame()
