# =============================================================
# modules/company_profile.py
# 公司基本資料 + 貨幣換算模組 (All yfinance)
# 鐵律：保留所有原始欄位名稱、Country→Currency 轉換、第 7 列插入邏輯
# =============================================================

import time
import random
import logging
import requests
import yfinance as yf
import pandas as pd
from datetime import datetime

logger = logging.getLogger(__name__)

MAX_RETRIES = 3

def fetch_company_profile(symbol: str, market: str, session: requests.Session) -> pd.DataFrame:
    """
    抓取公司基本資料並回傳清洗後的 DataFrame (All yfinance)。
    """
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            today_str = datetime.today().strftime("%Y-%m-%d")

            # --- yfinance 全面替換引擎 ---
            # 台股/日股 自動加上後綴
            yf_symbol = symbol
            if market == "TW":
                for suffix in [".TW", ".TWO", ".T"]:
                    test_symbol = f"{symbol}{suffix}"
                    if not yf.Ticker(test_symbol).history(period="1d").empty:
                        yf_symbol = test_symbol
                        break

            ticker = yf.Ticker(yf_symbol)
            info = ticker.info
            fast_info = ticker.fast_info
            
            if not info:
                logger.warning(f"[{symbol}] yfinance info 為空")
                info = {}

            data_dict = {
                "Date":                          today_str,
                "Ticker":                        yf_symbol,
                "Company Name":                  info.get("longName"),
                "Sector":                        info.get("sector"),
                "Industry":                      info.get("industry"),
                "Country":                       info.get("country"),
                "Currency":                      info.get("currency"),
                "Current Price":                 fast_info.get("lastPrice"),
                "Market Cap":                    info.get("marketCap"),
                "Enterprise Value":              info.get("enterpriseValue"),
                "Trailing PE":                   info.get("trailingPE"),
                "Forward PE":                    info.get("forwardPE"),
                "EPS (TTM)":                     info.get("trailingEps"),
                "Dividend Yield":                info.get("dividendYield"),
                "Beta":                          info.get("beta"),
                "52 Week High":                  info.get("fiftyTwoWeekHigh"),
                "52 Week Low":                   info.get("fiftyTwoWeekLow"),
                "Shares Outstanding":            info.get("sharesOutstanding"),
                "Revenue (TTM)":                 info.get("totalRevenue"),
                "Net Income (TTM)":              info.get("netIncomeToCommon"),
                "Website":                       info.get("website"),
                "Float Shares":                  info.get("floatShares"),
                "Implied Shares Outstanding":    info.get("impliedSharesOutstanding"),
                "Held by Insiders (%)":          info.get("heldPercentInsiders"),
                "Held by Institutions (%)":      info.get("heldPercentInstitutions"),
                "Short Shares":                  info.get("sharesShort"),
                "Short Prior Month":             info.get("sharesShortPriorMonth"),
                "Short % of Shares Outstanding": info.get("shortPercentOfFloat"),
            }

            # ========= DataFrame 轉換 (保留原始邏輯) =========
            df = pd.DataFrame(list(data_dict.items()), columns=["Item", "Value"])
            df = df.fillna("")

            country_value = df.loc[df["Item"] == "Country", "Value"].values
            country_name  = country_value[0] if len(country_value) > 0 else ""

            country_currency_map = {
                "Japan": "JPY", "Taiwan": "TWD", "United States": "USD", "USA": "USD",
                "China": "CNY", "Hong Kong": "HKD", "United Kingdom": "GBP",
                "South Korea": "KRW", "Germany": "EUR", "France": "EUR",
                "Canada": "CAD", "Australia": "AUD", "Singapore": "SGD",
                "Switzerland": "CHF", "Ireland": "EUR", "US": "USD"
            }
            converted_currency = country_currency_map.get(country_name, "")

            insert_position = 6
            new_row = pd.DataFrame([["Country Converted Currency", converted_currency]], columns=["Item", "Value"])
            df = pd.concat([df.iloc[:insert_position], new_row, df.iloc[insert_position:]], ignore_index=True)

            logger.info(f"[Profile] {yf_symbol} 抓取成功（{len(df)} 列）")
            return df

        except Exception as e:
            logger.warning(f"[Profile] {symbol} 第 {attempt}/{MAX_RETRIES} 次失敗: {e}")
            if attempt < MAX_RETRIES:
                time.sleep(random.uniform(3, 7))

    logger.error(f"[Profile] {symbol} 超過重試上限，回傳空 DataFrame")
    return pd.DataFrame(columns=["Item", "Value"])
