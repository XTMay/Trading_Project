import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

def fetch_historical_stock_price(ticker_symbol):
    start_date = "2014-01-01"
    end_date = (datetime.today() + timedelta(days=1)).strftime("%Y-%m-%d")
    print(f"[{ticker_symbol}] 啟動歷史股價抓取...")

    stock = yf.Ticker(ticker_symbol)

    try:
        df = stock.history(start=start_date, end=end_date, auto_adjust=False)
    except Exception as e:
        print(f"❌ 無法取得歷史股價: {e}")
        return pd.DataFrame()

    if df.empty:
        print("⚠ 無資料")
        return pd.DataFrame()

    monthly_df = df.resample('MS').agg({
        'Open': 'first',
        'High': 'max',
        'Low': 'min',
        'Close': 'last',
        'Adj Close': 'last',
        'Volume': 'sum'
    })

    try:
        actions = stock.actions
        if not actions.empty:
            actions = actions.loc[start_date:end_date]
            actions = actions[
                (actions['Dividends'] != 0) |
                (actions['Stock Splits'] != 0)
            ]
        else:
            actions = pd.DataFrame()
    except:
        actions = pd.DataFrame()

    combined = pd.concat([monthly_df, actions], axis=0)

    for col in ['Dividends', 'Stock Splits']:
        if col not in combined.columns:
            combined[col] = 0
        else:
            combined[col] = combined[col].fillna(0)

    combined['Entry_Type'] = "Month_Start"

    if not actions.empty:
        combined.loc[actions.index, 'Entry_Type'] = "Corporate_Action"

    combined = combined.sort_index(ascending=False)
    combined.index = combined.index.strftime('%Y/%m/%d')
    combined.index.name = "Date"

    return combined.reset_index()