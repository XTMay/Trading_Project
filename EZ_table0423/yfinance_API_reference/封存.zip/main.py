# =============================================================
# main.py — 財報背景資料引擎 大腦中樞
# Windows 環境，唯一進入點
# =============================================================

import sys
import time
import random
import logging
import requests
import xlwings as xw
import numpy as np
import pandas as pd

from modules.company_profile import fetch_company_profile
from modules.is_financials    import fetch_is_financials
from modules.bs_financials    import fetch_bs_financials
from IS_Financials_5Q_plus_TTM_with_Unusual import fetch_is_5q_plus_ttm
from BS_Financials_5Q_TTM import fetch_bs_5q_ttm
from CFS_Financials_5Y_TTM import fetch_cfs_5y_ttm
from Historical_stock_price_adj import fetch_historical_stock_price
from Foreign_exchange_rates import fetch_foreign_exchange_rates
from Company_Dividends_Action import fetch_dividends_action

# ──────────────────────────────────────────────────────────────
# 0. Logging 設定（漂亮的 INFO/SUCCESS/ERROR）
# ──────────────────────────────────────────────────────────────
logging.addLevelName(25, "SUCCESS")

def _success(self, message, *args, **kwargs):
    if self.isEnabledFor(25):
        self._log(25, message, args, **kwargs)

logging.Logger.success = _success

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("main")

logging.getLogger('yfinance').setLevel(logging.WARNING)
logging.getLogger('urllib3').setLevel(logging.WARNING)
logging.getLogger('requests').setLevel(logging.WARNING)


# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 1. classify_symbol (雙引擎智慧路由)
# ──────────────────────────────────────────────────────────────
from modules.fmp_client import classify_symbol


# ──────────────────────────────────────────────────────────────
# 2. 全域 Session（Windows Chrome User-Agent）
# ──────────────────────────────────────────────────────────────
def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7",
    })
    return session


# ──────────────────────────────────────────────────────────────
# 3. xlwings 綁定（優先找有「美股」工作表的 xlsm）
# ──────────────────────────────────────────────────────────────
def bind_xlsm():
    """
    掃描所有已開啟的 xlsm，優先綁定含「美股」工作表的活頁簿。
    回傳 (wb, sheet_美股) 或 raise RuntimeError。
    """
    def _find(books_iter):
        best = None
        for b in books_iter:
            if not b.name.endswith(".xlsm") or b.name.startswith("~$"):
                continue
            try:
                s = b.sheets["美股"]
                return b, s       # 找到「美股」工作表，立刻回傳
            except Exception:
                if best is None:
                    best = b      # 備援
        return (best, best.sheets[0]) if best else (None, None)

    wb = sheet = None

    for a in xw.apps:
        wb, sheet = _find(a.books)
        if wb:
            break

    if wb is None:
        wb, sheet = _find(xw.books)

    if wb is None:
        raise RuntimeError(
            "❌ 找不到含「美股」工作表的開啟中 .xlsm，"
            "請先在 Excel 開啟目標活頁簿再執行！"
        )

    logger.info(f"[Bind] 成功綁定: {wb.name}　工作表: 美股")
    return wb, sheet


# ──────────────────────────────────────────────────────────────
# 4. DataFrame → xlwings 橫向寫入 (Cell Injection 精準寫入)
# ──────────────────────────────────────────────────────────────
def write_df_to_sheet(sheet, df, start_cell):
    import pandas as pd
    import numpy as np
    
    if df is None or df.empty:
        return
        
    df_clean = df.copy()
    
    # 1. 欄位名稱強制轉文字 (yfinance 的欄位常為 Timestamp)
    df_clean.columns = df_clean.columns.astype(str)
    
    # 2. 強制將所有時間格式 (datetime64, datetimetz) 轉為字串
    for col in df_clean.select_dtypes(include=['datetime', 'datetimetz']).columns:
        df_clean[col] = df_clean[col].astype(str)
        
    # 3. 處理無限大數值
    df_clean = df_clean.replace([np.inf, -np.inf], np.nan)
    
    # 4. 終極殺招：將所有的 NaN, NaT, <NA> 等空值，全部暴力替換為空字串 ""
    # Windows Excel COM 介面對空字串的相容性是 100%
    df_clean = df_clean.fillna("")
    
    try:
        sheet.range(start_cell).options(index=False, header=True).value = df_clean
    except Exception as e:
        print(f"[Error] 寫入 {start_cell} 失敗，錯誤訊息: {e}")


# ──────────────────────────────────────────────────────────────
# 5. 主流程
# ──────────────────────────────────────────────────────────────
def main():
    logger.info("=" * 60)
    logger.info("財報背景資料引擎 啟動")
    logger.info("=" * 60)

    # ── 5-1. 建立全域 Session ──────────────────────────────────
    session = build_session()
    logger.info("[Session] Windows Chrome User-Agent 設定完成")

    # ── 5-2. 綁定 xlsm ────────────────────────────────────────
    try:
        wb, sheet = bind_xlsm()
    except RuntimeError as e:
        logger.error(str(e))
        sys.exit(1)

    # ── 5-3. 讀取 A2 股票代碼 ─────────────────────────────────
    raw_code = sheet.range("A2").value
    if not raw_code:
        logger.error("[Read] A2 為空，請在「美股」工作表的 A2 輸入股票代碼！")
        sys.exit(1)

    raw_code = str(raw_code).strip()
    logger.info(f"[Read] A2 原始代碼: {raw_code}")

    symbol, market = classify_symbol(raw_code)
    if market == 'skip' or not symbol:
        logger.error(f"[Ticker] 無效代碼或略過: {raw_code}")
        sys.exit(1)
        
    logger.info(f"[Ticker] 分類代碼: {symbol} (Market: {market})")

    # ── 5-4. Company Profile ───────────────────────────────────
    logger.info("[API] 抓取 Company Profile...")
    time.sleep(random.uniform(2, 5))
    df_profile = fetch_company_profile(symbol, market, session)

    if not df_profile.empty:
        logger.log(25, f"[SUCCESS] Company Profile 抓取完成（{len(df_profile)} 列）")
    else:
        logger.error("[ERROR] Company Profile 抓取失敗")

    # ── 5-5. IS 損益表 (年) ────────────────────────────────────
    logger.info("[API] 抓取 IS 損益表（年/5Y）...")
    time.sleep(random.uniform(2, 5))
    df_is = fetch_is_financials(symbol, market, session)

    if not df_is.empty:
        logger.log(25, f"[SUCCESS] IS Financials 抓取完成（{len(df_is)} 列）")
    else:
        logger.error("[ERROR] IS Financials 抓取失敗")

    # ── 5-6. BS 資產負債表 (年) ────────────────────────────────
    logger.info("[API] 抓取 BS 資產負債表（年/5Y）...")
    time.sleep(random.uniform(2, 5))
    df_bs = fetch_bs_financials(symbol, market, session)

    if not df_bs.empty:
        logger.log(25, f"[SUCCESS] BS Financials 抓取完成（{len(df_bs)} 列）")
    else:
        logger.error("[ERROR] BS Financials 抓取失敗")

    # ── 5-6-1. IS 損益表 (季) ──────────────────────────────────
    logger.info("[API] 抓取 IS 損益表（季/5Q）...")
    time.sleep(random.uniform(2, 5))
    df_is_5q = fetch_is_5q_plus_ttm(symbol)

    if not df_is_5q.empty:
        logger.log(25, f"[SUCCESS] IS Financials 5Q 抓取完成（{len(df_is_5q)} 列）")
    else:
        logger.error("[ERROR] IS Financials 5Q 抓取失敗")

    # ── 5-6-2. BS 資產負債表 (季) ──────────────────────────────
    logger.info("[API] 抓取 BS 資產負債表（季/5Q）...")
    time.sleep(random.uniform(2, 5))
    df_bs_5q = fetch_bs_5q_ttm(symbol)

    if not df_bs_5q.empty:
        logger.log(25, f"[SUCCESS] BS Financials 5Q 抓取完成（{len(df_bs_5q)} 列）")
    else:
        logger.error("[ERROR] BS Financials 5Q 抓取失敗")

    # ── 5-6-3. CFS 現金流量表 (年) ─────────────────────────────
    logger.info("[API] 抓取 CFS 現金流量表（年/5Y）...")
    time.sleep(random.uniform(2, 5))
    df_cfs_5y = fetch_cfs_5y_ttm(symbol)

    if not df_cfs_5y.empty:
        logger.log(25, f"[SUCCESS] CFS Financials 5Y 抓取完成（{len(df_cfs_5y)} 列）")
    else:
        logger.error("[ERROR] CFS Financials 5Y 抓取失敗")

    # ── 5-6-4. 歷史股價 ────────────────────────────────────────
    logger.info("[API] 抓取 歷史股價...")
    time.sleep(random.uniform(2, 5))
    df_historical = fetch_historical_stock_price(symbol)

    if not df_historical.empty:
        logger.log(25, f"[SUCCESS] 歷史股價 抓取完成（{len(df_historical)} 列）")
    else:
        logger.error("[ERROR] 歷史股價 抓取失敗")

    # ── 5-6-5. 匯率 ────────────────────────────────────────────
    logger.info("[API] 抓取 匯率...")
    time.sleep(random.uniform(2, 5))
    df_exchange = fetch_foreign_exchange_rates("TWD")

    if not df_exchange.empty:
        logger.log(25, f"[SUCCESS] 匯率 抓取完成（{len(df_exchange)} 列）")
    else:
        logger.error("[ERROR] 匯率 抓取失敗")

    # ── 5-6-6. 股息與股票分割 ──────────────────────────────────────────
    logger.info("[API] 抓取 股息與股票分割...")
    time.sleep(random.uniform(2, 5))
    df_dividends_action = fetch_dividends_action(symbol)

    if not df_dividends_action.empty:
        logger.log(25, f"[SUCCESS] 股息與股票分割 抓取完成（{len(df_dividends_action)} 列）")
    else:
        logger.error("[ERROR] 股息與股票分割 抓取失敗")

    # ── 5-7. 橫向寫入 xlsm (Cell Injection) ─────────────────────
    #
    # 寫入佈局：
    #   AE1 : Profile  (日)
    #   AM1 : IS       (年)
    #   AZ1 : BS       (年)
    #   BG1 : IS_5Q    (季)
    #   BQ1 : BS_5Q    (季)
    #   CA1 : CFS_5Y   (年)
    #   CK1 : 歷史股價
    #   CU1 : 匯率
    #   DE1 : 股息與股票分割
    #
    logger.info("[Write] 開始寫入「美股」工作表...")

    write_df_to_sheet(sheet, df_profile, "AE1")   # Profile → AE
    write_df_to_sheet(sheet, df_is,      "AM1")   # IS(年)  → AM
    write_df_to_sheet(sheet, df_bs,      "AZ1")   # BS(年)  → AZ
    write_df_to_sheet(sheet, df_is_5q,   "BG1")   # IS(季)  → BG
    write_df_to_sheet(sheet, df_bs_5q,   "BQ1")   # BS(季)  → BQ
    write_df_to_sheet(sheet, df_cfs_5y,  "CA1")   # CFS(年) → CA
    write_df_to_sheet(sheet, df_historical, "CK1")  # 歷史股價
    write_df_to_sheet(sheet, df_exchange, "CU1")    # 匯率
    write_df_to_sheet(sheet, df_dividends_action, "DE1") # 股息與股票分割

    # ── 5-8. 儲存與預留 VBA 呼叫 ─────────────────────────────────
    wb.save()
    
    # [預留區] 未來若需自動觸發 Excel 的 VBA 巨集，可取消此行註解：
    # try:
    #     wb.app.macro('MacroName')()
    #     logger.info("[Macro] 成功執行 VBA 巨集 MacroName")
    # except Exception as e:
    #     logger.warning(f"[Macro] 執行 VBA 巨集失敗: {e}")

    # ── 5-9. 鐵證輸出 ──────────────────────────────────────────
    try:
        exact_path = wb.fullname
        logger.log(25, "\n" + "!" * 60)
        logger.log(25, "【系統鐵證：寫入成功，請直接去以下路徑找檔案】")
        logger.log(25, f"📂 檔案絕對路徑: {exact_path}")
        logger.log(25, "📊 寫入工作表: 美股")
        logger.log(25, "📍 寫入範圍: AE(Profile)｜AM(IS年)｜AZ(BS年)｜BG(IS季)｜BQ(BS季)｜CA(CFS年)｜CK(歷史股價)｜CU(匯率)｜DE(股息與股票分割)")
        logger.log(25, "!" * 60)
    except Exception:
        pass

    logger.info("=" * 60)
    logger.info("財報背景資料引擎 執行結束")
    logger.info("=" * 60)


# ──────────────────────────────────────────────────────────────
# Windows 多线程保護
# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    main()
