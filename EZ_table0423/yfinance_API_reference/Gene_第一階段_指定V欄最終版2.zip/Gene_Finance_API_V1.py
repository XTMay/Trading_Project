import xlwings as xw
import yfinance as yf
import pandas as pd
import time
from datetime import datetime
import re
import random
import os
import pathlib
import requests
import concurrent.futures

# ==========================================
# 1. 頂端變數區 (Config)
# ==========================================

# 動態搜尋與腳本同資料夾下第一個 .xlsm 檔案 (Windows 相容)
_script_dir = pathlib.Path(__file__).parent.resolve()
_xlsm_files = list(_script_dir.glob('*.xlsm'))
if not _xlsm_files:
    raise FileNotFoundError(
        f"在目錄 {_script_dir} 中找不到任何 .xlsm 檔案，請確認目標活頁簿存在！"
    )
TARGET_EXCEL      = str(_xlsm_files[0])
TARGET_EXCEL_NAME = _xlsm_files[0].name

STOCK_LIST_START_ROW = 2      # 股票清單起始列
STOCK_SYMBOL_COLUMN  = "V"    # 股票代碼欄位
MAX_WORKERS          = 2      # 多執行緒併發數 (Anti-Ban 2.0 降至 2)
BATCH_SIZE           = 50     # 每批次處理筆數
BATCH_COOLDOWN       = 30     # 每批次完成後冷卻秒數
FAILED_LOG_FILE      = 'failed_stocks.txt'

# 建立全域偽裝 Session（各執行緒共用，避免重複建立）
_session = requests.Session()
_session.headers.update({
    'User-Agent': (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    )
})

# ==========================================
# 2. 智能代碼分類規則
# ==========================================
# 規則 A (美股)：純英文字母，長度 1~5
_RULE_US  = re.compile(r'^[A-Za-z]{1,5}$')
# 規則 B (台/日股)：精準 4 碼純數字
_RULE_TW  = re.compile(r'^\d{4}$')
# 規則 C (垃圾資料)：5 碼以上純數字 → 過濾
_RULE_BAD = re.compile(r'^\d{5,}$')


def classify_symbol(raw_val):
    """
    從 Excel 原始值提取並分類代碼。
    回傳 (symbol, market) 或 (None, 'skip') 表示跳過。
    market: 'US' | 'TW' | 'skip'
    """
    raw_str = str(raw_val).strip()

    # 先嘗試擷取開頭連續純數字（支援「1108 幸福」、「$2330」格式）
    num_match = re.match(r'^[^\d]*(\d+)', raw_str)
    alpha_match = re.match(r'^([A-Za-z]{1,5})$', raw_str)

    if alpha_match:
        # 純英文美股代碼
        return alpha_match.group(1).upper(), 'US'

    if num_match:
        digits = num_match.group(1)
        if _RULE_TW.match(digits):
            return digits, 'TW'
        else:
            # 5 碼以上數字 (權證等垃圾) → 直接跳過
            return None, 'skip'

    # 其他無法識別 → 跳過
    return None, 'skip'


def get_ticker_for_symbol(symbol, market):
    """
    根據市場類型取得有效的 yfinance Ticker。
    台/日股嘗試順序：.TW → .TWO → .T
    美股：直接測試。
    回傳 (ticker, valid_symbol) 或 (None, symbol)。
    """
    if market == 'TW':
        for suffix in ['.TW', '.TWO', '.T']:
            full = f"{symbol}{suffix}"
            t = yf.Ticker(full)
            hist = t.history(period="1d", timeout=10)
            if not hist.empty:
                return t, full
        return None, symbol
    else:
        # 美股或其他
        t = yf.Ticker(symbol)
        hist = t.history(period="1d", timeout=10)
        if not hist.empty:
            return t, symbol
        return None, symbol


# ==========================================
# 3. 多執行緒抓取任務 (絕對禁止碰 xlwings)
# ==========================================
def fetch_stock_data(task_info):
    """ThreadPoolExecutor 任務函式；單純抓取，不寫入 Excel。"""
    current_row  = task_info['row']
    original_val = task_info['original_val']

    # --- 智能分類 ---
    symbol, market = classify_symbol(original_val)

    if market == 'skip' or symbol is None:
        print(f"[Skip] Row {current_row}: '{original_val}' → 非普通股或格式無法識別，跳過", flush=True)
        return {
            'row': current_row, 'success': False,
            'original': original_val,
            'error': '非普通股或格式無法識別 (已跳過)'
        }

    print(f"[Thread] Row {current_row}: '{original_val}' → {symbol} ({market})", flush=True)

    # 隨機延遲 2~5 秒 (Anti-Ban 2.0)，模擬人類請求節奏
    time.sleep(random.uniform(2, 5))

    MAX_RETRIES = 3
    last_error  = ""

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            ticker, valid_symbol = get_ticker_for_symbol(symbol, market)

            if not ticker:
                print(f"[Error] Row {current_row} ({symbol}): 查無資料或已下市", flush=True)
                return {
                    'row': current_row, 'success': False,
                    'symbol': symbol, 'original': original_val,
                    'error': '查無 API 資料或下市'
                }

            info = ticker.info

            company_name  = info.get('longName', valid_symbol)
            sector        = info.get('sector', 'N/A')
            industry      = info.get('industry', 'N/A')
            current_price = info.get('currentPrice', info.get('regularMarketPrice', 'N/A'))
            today_date    = datetime.now().strftime("%Y-%m-%d")
            currency      = info.get('currency', 'N/A')
            market_cap    = info.get('marketCap', 'N/A')

            info_string = f"{company_name} | {sector} / {industry} | Price: {current_price} | {today_date}"

            hist = ticker.history(start="2014-01-01", interval="1mo", timeout=30)
            dates_str, prices = [], []
            if not hist.empty:
                dates_str = [d.strftime("%Y-%m") for d in hist['Close'].index]
                prices    = hist['Close'].values.tolist()

            print(f"[✅ OK]  Row {current_row}: {valid_symbol} ({company_name})", flush=True)
            return {
                'row': current_row, 'success': True,
                'symbol': valid_symbol, 'original': original_val,
                'info_string': info_string,
                'currency': currency,
                'market_cap': market_cap,
                'dates_str': dates_str,
                'prices': prices
            }

        except Exception as e:
            last_error = str(e)
            if attempt < MAX_RETRIES:
                print(
                    f"[Retry {attempt}/{MAX_RETRIES}] Row {current_row} ({symbol}): {last_error}",
                    flush=True
                )
                time.sleep(2)
            else:
                print(f"[❌ Fail] Row {current_row} ({symbol}) 三次重試全失敗: {last_error}", flush=True)
                return {
                    'row': current_row, 'success': False,
                    'symbol': symbol, 'original': original_val,
                    'error': last_error
                }


# ==========================================
# 4. 主流程：三階段架構
# ==========================================
def run():
    print("=" * 60, flush=True)
    print("Gene 財經 API 引擎 - 台美日通吃多線程交付版", flush=True)
    print(f"目標檔案: {TARGET_EXCEL_NAME}", flush=True)
    print(f"最大併發數: {MAX_WORKERS}", flush=True)
    print("=" * 60, flush=True)

    app = wb = None
    tasks_to_fetch = []

    try:
        # ==========================================
        # 【階段一】單線程安全讀取
        # ==========================================
        print("\n【階段一】(單線程) 讀取 Excel 股票清單...", flush=True)

        # Mac 相容綁定邏輯：多重備援策略
        try:
            wb = None
            # 策略一：嘗試從所有已開啟的 apps 中找到 xlsm 活頁簿
            for a in xw.apps:
                for b in a.books:
                    if b.name.endswith('.xlsm') and not b.name.startswith('~$'):
                        wb  = b
                        app = a
                        break
                if wb:
                    break

            # 策略二：若找不到，嘗試直接用 xw.books 全域清單
            if wb is None:
                for b in xw.books:
                    if b.name.endswith('.xlsm') and not b.name.startswith('~$'):
                        wb  = b
                        app = wb.app
                        break

            if wb is None:
                print("❌ 找不到開啟中的 .xlsm 檔案，請先手動開啟目標活頁簿後再執行！", flush=True)
                return

            sheet = wb.sheets["收藏"]
            print(f"-> 成功綁定: {wb.name} (共 {len(wb.sheets)} 個工作表)", flush=True)

        except Exception as e:
            print(f"❌ 綁定 Excel 失敗: {e}", flush=True)
            return


        # 動態讀取所有資料 (不限筆數)
        raw_values = sheet.range(
            f"{STOCK_SYMBOL_COLUMN}{STOCK_LIST_START_ROW}"
        ).expand('down').value

        if not isinstance(raw_values, list):
            raw_values = [raw_values]

        for idx, val in enumerate(raw_values):
            if val is None:
                break
            tasks_to_fetch.append({
                'row': STOCK_LIST_START_ROW + idx,
                'original_val': val
            })

        total = len(tasks_to_fetch)
        print(f"-> 共讀取 {total} 筆資料，準備進入多線程抓取...", flush=True)

        # ==========================================
        # 【階段二】多線程 API 抓取 (釋放 Excel 控制)
        # ==========================================
        print(f"\n【階段二】(多線程 x{MAX_WORKERS}) 開始抓取 API...", flush=True)
        print(f"⏱  每批 {BATCH_SIZE} 筆後冷卻 {BATCH_COOLDOWN} 秒，防止 Rate Limit", flush=True)
        results       = []
        completed_cnt = 0

        # 將任務切成批次，每批完成後強制冷卻
        for batch_start in range(0, total, BATCH_SIZE):
            batch = tasks_to_fetch[batch_start : batch_start + BATCH_SIZE]
            batch_num = batch_start // BATCH_SIZE + 1
            total_batches = (total + BATCH_SIZE - 1) // BATCH_SIZE
            print(f"\n--- 批次 {batch_num}/{total_batches}：處理 Row {batch[0]['row']} ~ Row {batch[-1]['row']} ---", flush=True)

            with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_map = {
                    executor.submit(fetch_stock_data, task): task
                    for task in batch
                }
                for future in concurrent.futures.as_completed(future_map):
                    try:
                        res = future.result()
                        results.append(res)
                    except Exception as exc:
                        task = future_map[future]
                        results.append({
                            'row': task['row'], 'success': False,
                            'original': task['original_val'],
                            'error': f'執行緒例外: {exc}'
                        })
                    completed_cnt += 1
                    print(
                        f"\rProgress: {completed_cnt}/{total} 筆完成...",
                        end="", flush=True
                    )

            # 每批次結束後冷卻 (最後一批不用等)
            if batch_start + BATCH_SIZE < total:
                print(f"\n⏸  批次 {batch_num} 完成！冷卻 {BATCH_COOLDOWN} 秒防止 Rate Limit...", flush=True)
                time.sleep(BATCH_COOLDOWN)

        print(f"\n-> 抓取階段結束，共 {len(results)} 筆結果。", flush=True)

        # 依 row 排序，確保寫入順序正確
        results.sort(key=lambda x: x['row'])

        # ==========================================
        # 【階段三】單線程安全寫入 Excel
        # ==========================================
        print("\n【階段三】(單線程) 寫入 Excel...", flush=True)
        failed_stocks = []

        for res in results:
            row          = res['row']
            original_val = res.get('original', 'Unknown')

            if res['success']:
                sheet.range(f"BX{row}").value = res.get('info_string', '')
                sheet.range(f"CA{row}").value = f"Currency: {res.get('currency', 'N/A')}"
                sheet.range(f"CB{row}").value = res.get('market_cap', 'N/A')

                dates_str = res.get('dates_str', [])
                prices    = res.get('prices', [])

                if dates_str and row == STOCK_LIST_START_ROW:
                    sheet.range("CC1").value = dates_str
                if prices:
                    sheet.range(f"CC{row}").value = prices
            else:
                error_msg = res.get('error', '未知錯誤')
                failed_stocks.append(
                    f"Row {row} | 原始輸入: {original_val} | 錯誤原因: {error_msg}"
                )

        print("\n✅ 所有資料寫入完畢！", flush=True)
        wb.save()
        print("✅ 目標檔案已自動儲存！", flush=True)

        # 產出失敗日誌
        if failed_stocks:
            log_path = _script_dir / FAILED_LOG_FILE
            with open(log_path, 'w', encoding='utf-8') as f:
                f.write(f"--- API 抓取失敗紀錄 ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ---\n")
                f.write("請檢查以下代碼是否下市或格式有誤：\n\n")
                for entry in failed_stocks:
                    f.write(entry + "\n")
            print(f"⚠️  發現 {len(failed_stocks)} 筆失敗，已寫入: {FAILED_LOG_FILE}", flush=True)
        else:
            print("🎉 所有股票皆成功抓取，無失敗紀錄！", flush=True)

    except Exception as e:
        print(f"\n❌ 嚴重錯誤: {e}", flush=True)

    finally:
        wb = None
        app = None

    print("\n" + "=" * 60, flush=True)
    print("Gene 引擎執行結束。", flush=True)
    print("=" * 60, flush=True)


if __name__ == "__main__":
    run()
