# =============================================================
# modules/bs_financials_5q.py
# 資產負債表 5Q + TTM 模組 (yfinance 專用)
# =============================================================

import time
import random
import logging
import requests
import yfinance as yf
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

MAX_RETRIES = 3

def sanitize_excel(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if col != "Item":
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.fillna("")
    return df

def check_quarter_integrity(df):
    dates = df.columns.sort_values()
    if len(dates) < 5:
        logger.warning(f"⚠ 季度資料不足5季 ({len(dates)})")
        return "LESS_THAN_5"
    diffs = np.diff(dates).astype("timedelta64[D]").astype(int)
    for d in diffs[-5:]:
        if not (70 <= d <= 120):
            logger.warning(f"⚠ 偵測到季度不連續, diffs: {diffs[-5:]}")
            return "BROKEN"
    return "VALID"

def fetch_bs_financials_5q(symbol: str, market: str, session: requests.Session) -> pd.DataFrame:
    """單一 yfinance 引擎 BS 5季抓取"""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            yf_symbol = symbol
            if market == 'TW':
                for suffix in [".TW", ".TWO", ".T"]:
                    test_symbol = f"{symbol}{suffix}"
                    if not yf.Ticker(test_symbol).history(period="1d").empty:
                        yf_symbol = test_symbol
                        break

            ticker = yf.Ticker(yf_symbol)
            bs_q = ticker.quarterly_balance_sheet

            if bs_q.empty:
                raise ValueError("❌ 無法取得季度 Balance Sheet")

            bs_q.columns = pd.to_datetime(bs_q.columns)
            bs_q = bs_q.sort_index(axis=1)

            # ========= 2️⃣ 檢查季度完整性 =========
            status = check_quarter_integrity(bs_q)

            # ========= 3️⃣ 決定輸出範圍 =========
            if status == "VALID":
                logger.info(f"[BS 5Q] {yf_symbol} 季度完整 → 輸出最近5季 + TTM")
                last_q = bs_q.iloc[:, -5:]

            elif status == "LESS_THAN_5":
                logger.info(f"[BS 5Q] {yf_symbol} 不足5季 → 輸出所有季度 + TTM")
                last_q = bs_q   # 🔥 全部季度

            else:  # BROKEN
                logger.info(f"[BS 5Q] {yf_symbol} 季度不連續 → 輸出最近單季 + TTM")
                last_q = bs_q.iloc[:, -1:]

            last_q.columns = last_q.columns.strftime("%Y-%m")

            # ========= 4️⃣ TTM（Balance Sheet = 最新季度） =========
            bs_ttm = bs_q.iloc[:, -1:].copy()
            bs_ttm.columns = ["TTM"]

            # ========= 5️⃣ 合併 =========
            combined = last_q.merge(
                bs_ttm,
                left_index=True,
                right_index=True,
                how="left"
            )

            # ========= 6️⃣ 清洗 =========
            combined.index.name = "Item"
            combined_output = combined.reset_index()
            combined_output = sanitize_excel(combined_output)

            logger.info(f"[BS 5Q] {yf_symbol} 抓取成功（{len(combined_output)} 列）")
            return combined_output

        except Exception as e:
            logger.warning(f"[BS 5Q] {symbol} 第 {attempt}/{MAX_RETRIES} 次失敗: {e}")
            if attempt < MAX_RETRIES:
                time.sleep(random.uniform(3, 7))

    logger.error(f"[BS 5Q] {symbol} 超過重試上限，回傳空 DataFrame")
    return pd.DataFrame()
