import yfinance as yf
import pandas as pd
import numpy as np

def fetch_bs_5q_ttm(ticker_symbol):
    print(f"[{ticker_symbol}] 啟動 BS 5Q+TTM 抓取...")
    ticker = yf.Ticker(ticker_symbol)

    try:
        bs_q = ticker.quarterly_balance_sheet
    except Exception as e:
        print(f"❌ 無法取得季度 Balance Sheet: {e}")
        return pd.DataFrame()

    if bs_q is None or bs_q.empty:
        print("❌ 無法取得季度 Balance Sheet")
        return pd.DataFrame()

    bs_q.columns = pd.to_datetime(bs_q.columns)
    bs_q = bs_q.sort_index(axis=1)

    def check_quarter_integrity(df):
        dates = df.columns.sort_values()
        if len(dates) < 5:
            print("⚠ 季度資料不足5季")
            return "LESS_THAN_5"
        diffs = np.diff(dates).astype("timedelta64[D]").astype(int)
        for d in diffs[-5:]:
            if not (70 <= d <= 120):
                print("⚠ 偵測到季度不連續")
                return "BROKEN"
        return "VALID"

    status = check_quarter_integrity(bs_q)

    if status == "VALID":
        print("✅ 季度完整 → 輸出最近5季 + TTM")
        last_q = bs_q.iloc[:, -5:]
    elif status == "LESS_THAN_5":
        print("🔄 不足5季 → 輸出所有季度 + TTM")
        last_q = bs_q
    else:
        print("🔄 季度不連續 → 輸出最近單季 + TTM")
        last_q = bs_q.iloc[:, -1:]

    last_q.columns = last_q.columns.strftime("%Y-%m")

    bs_ttm = bs_q.iloc[:, -1:].copy()
    bs_ttm.columns = ["TTM"]

    combined = last_q.merge(
        bs_ttm,
        left_index=True,
        right_index=True,
        how="left"
    )

    def sanitize_excel(df):
        df = df.copy()
        for col in df.columns:
            if col != "Item":
                df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.replace([np.inf, -np.inf], np.nan)
        df = df.fillna("")
        return df

    combined.index.name = "Item"
    combined_output = combined.reset_index()
    combined_output = sanitize_excel(combined_output)

    return combined_output