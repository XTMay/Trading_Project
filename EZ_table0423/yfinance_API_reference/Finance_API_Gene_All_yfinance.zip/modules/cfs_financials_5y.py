# =============================================================
# modules/cfs_financials_5y.py
# 現金流量表 5Y + TTM 模組 (yfinance 專用)
# =============================================================

import time
import random
import logging
import requests
import yfinance as yf
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

MAX_RETRIES = 3

def sanitize_excel(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if col != "Item":
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.fillna("")
    return df

def check_year_integrity(df):
    dates = df.columns.sort_values()
    if len(dates) < 5:
        logger.warning(f"⚠ 年度資料不足5年 ({len(dates)})")
        return "LESS_THAN_5"
    diffs = np.diff(dates).astype("timedelta64[D]").astype(int)
    for d in diffs[-5:]:
        if not (330 <= d <= 400):
            logger.warning(f"⚠ 偵測到年度不連續, diffs: {diffs[-5:]}")
            return "BROKEN"
    return "VALID"

def fetch_cfs_financials_5y(symbol: str, market: str, session: requests.Session) -> pd.DataFrame:
    """單一 yfinance 引擎 CFS 5年抓取"""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            yf_symbol = symbol
            if market == 'TW':
                for suffix in [".TW", ".TWO", ".T"]:
                    test_symbol = f"{symbol}{suffix}"
                    if not yf.Ticker(test_symbol).history(period="1d").empty:
                        yf_symbol = test_symbol
                        break

            ticker = yf.Ticker(yf_symbol)
            
            # ========= 1️⃣ 抓年度 Cash Flow =========
            cf_y = ticker.cashflow
            if cf_y.empty:
                raise ValueError("❌ 無法取得年度 Cash Flow")

            cf_y.columns = pd.to_datetime(cf_y.columns)
            cf_y = cf_y.sort_index(axis=1)

            # ========= 2️⃣ 抓季度 Cash Flow（若有） =========
            try:
                cf_q = ticker.quarterly_cashflow
            except:
                cf_q = pd.DataFrame()

            if not cf_q.empty:
                cf_q.columns = pd.to_datetime(cf_q.columns)
                cf_q = cf_q.sort_index(axis=1)

            # ========= 3️⃣ 檢查年度完整性 =========
            status = check_year_integrity(cf_y)

            # ========= 4️⃣ 決定年度輸出範圍 =========
            if status == "VALID":
                logger.info(f"[CFS 5Y] {yf_symbol} 年度完整 → 輸出最近5年")
                last_y = cf_y.iloc[:, -5:]

            elif status == "LESS_THAN_5":
                logger.info(f"[CFS 5Y] {yf_symbol} 不足5年 → 輸出所有年度")
                last_y = cf_y

            else:
                logger.info(f"[CFS 5Y] {yf_symbol} 年度不連續 → 輸出最近單年")
                last_y = cf_y.iloc[:, -1:]

            last_y.columns = last_y.columns.strftime("%Y")

            # ========= 5️⃣ 計算 TTM =========
            if not cf_q.empty:
                if cf_q.shape[1] >= 4:
                    logger.info(f"[CFS 5Y] {yf_symbol} 使用最近4季加總計算 TTM")
                    last_4q = cf_q.iloc[:, -4:]
                    cf_ttm = last_4q.sum(axis=1).to_frame(name="TTM")
                else:
                    logger.warning(f"[CFS 5Y] {yf_symbol} 季度不足4季 → 使用最近季度")
                    cf_ttm = cf_q.iloc[:, -1:].copy()
                    cf_ttm.columns = ["TTM"]
            else:
                logger.warning(f"[CFS 5Y] {yf_symbol} 無法取得季度資料 → 使用最新年度作為 TTM")
                cf_ttm = cf_y.iloc[:, -1:].copy()
                cf_ttm.columns = ["TTM"]

            # ========= 6️⃣ 合併 =========
            combined = last_y.merge(
                cf_ttm,
                left_index=True,
                right_index=True,
                how="left"
            )

            # ========= 7️⃣ 清洗 =========
            combined.index.name = "Item"
            combined_output = combined.reset_index()
            combined_output = sanitize_excel(combined_output)

            logger.info(f"[CFS 5Y] {yf_symbol} 抓取成功（{len(combined_output)} 列）")
            return combined_output

        except Exception as e:
            logger.warning(f"[CFS 5Y] {symbol} 第 {attempt}/{MAX_RETRIES} 次失敗: {e}")
            if attempt < MAX_RETRIES:
                time.sleep(random.uniform(3, 7))

    logger.error(f"[CFS 5Y] {symbol} 超過重試上限，回傳空 DataFrame")
    return pd.DataFrame()
