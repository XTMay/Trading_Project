import time
import requests
import pandas as pd
import json

# =============================================================
# 專案獨立 FMP API 抓取腳本 (Standalone FMP)
# 
# 使用情境：當需要繞過 yfinance，單純想直接測試或抓取 FMP
# 提供的財務/基本面數據時使用。此腳本與主產線 main.py 脫鉤，
# 直接印出結果或儲存獨立 CSV。
# =============================================================

# 請填入正確的 FMP API Key
FMP_API_KEY = "9Z3P6T9Q8M2K1R4J7X5V0W" # 替換為案主真實的 API KEY
BASE_URL = "https://financialmodelingprep.com/api/v3"

def get_fmp_json(endpoint: str, symbol: str, params: dict = None) -> list:
    """單純對 FMP 發送 GET 請求，回傳 JSON list"""
    if params is None:
        params = {}
    params['apikey'] = FMP_API_KEY
    
    url = f"{BASE_URL}{endpoint}/{symbol}"
    
    try:
        print(f"[FMP] 正在請求 {url.split('?')[0]} ...")
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # FMP sometimes returns error dict instead of list
        if isinstance(data, dict) and "Error Message" in data:
            print(f"[FMP Error] {data['Error Message']}")
            return []
            
        return data if isinstance(data, list) else [data]
        
    except requests.exceptions.HTTPError as e:
        if response.status_code == 403:
             print(f"[FMP ERROR] 403 Forbidden - 您的 API Key 等級不足以訪問此 Endpoint ({endpoint})")
        elif response.status_code == 401:
             print(f"[FMP ERROR] 401 Unauthorized - API Key 無效")
        else:
             print(f"[FMP ERROR] HTTP {response.status_code}: {e}")
        return []
    except Exception as e:
        print(f"[FMP ERROR] 連線失敗: {e}")
        return []

def demo_fmp_profile(symbol: str):
    print(f"\n--- 測試 FMP Company Profile ({symbol}) ---")
    data = get_fmp_json("/profile", symbol)
    if data:
        df = pd.DataFrame(data)
        print(df[["symbol", "companyName", "price", "mktCap", "sector", "industry"]].to_string())
    else:
        print("查無 Profile 資料或無權限。")

def demo_fmp_income_statement(symbol: str):
    print(f"\n--- 測試 FMP Income Statement (Annual, {symbol}) ---")
    data = get_fmp_json("/income-statement", symbol, params={"limit": 3})
    if data:
        df = pd.DataFrame(data)
        # 挑選幾個重要欄位展示
        cols_to_show = ["date", "symbol", "reportedCurrency", "revenue", "grossProfit", "netIncome"]
        available_cols = [c for c in cols_to_show if c in df.columns]
        print(df[available_cols].to_string())
    else:
        print("查無 Income Statement 資料或無權限。")

if __name__ == "__main__":
    print("=======================================")
    print(" FMP Premium API Standalone 測試腳本")
    print("=======================================")
    
    test_symbol = input("請輸入要查詢的股票代碼 (預設 AAPL): ").strip().upper()
    if not test_symbol:
        test_symbol = "AAPL"
        
    demo_fmp_profile(test_symbol)
    time.sleep(1) # 溫和一點
    demo_fmp_income_statement(test_symbol)
    
    print("\n[INFO] 測試結束。")
